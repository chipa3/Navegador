CREATE DATABASE  IF NOT EXISTS `db_clc` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `db_clc`;
-- MySQL dump 10.13  Distrib 8.0.21, for Win64 (x86_64)
--
-- Host: localhost    Database: db_clc
-- ------------------------------------------------------
-- Server version	8.0.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bitacora`
--

DROP TABLE IF EXISTS `bitacora`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bitacora` (
  `pk_id_bitacora` int NOT NULL AUTO_INCREMENT,
  `fk_idusuario_bitacora` int DEFAULT NULL,
  `fk_idaplicacion_bitacora` int DEFAULT NULL,
  `fechahora_bitacora` varchar(50) DEFAULT NULL,
  `direccionhost_bitacora` varchar(20) DEFAULT NULL,
  `nombrehost_bitacora` varchar(20) DEFAULT NULL,
  `accion_bitacora` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`pk_id_bitacora`),
  KEY `fk_login_bitacora` (`fk_idusuario_bitacora`),
  KEY `fk_aplicacion_bitacora` (`fk_idaplicacion_bitacora`),
  CONSTRAINT `fk_aplicacion_bitacora` FOREIGN KEY (`fk_idaplicacion_bitacora`) REFERENCES `aplicacion` (`pk_id_aplicacion`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `fk_login_bitacora` FOREIGN KEY (`fk_idusuario_bitacora`) REFERENCES `login` (`pk_id_login`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bitacora`
--

LOCK TABLES `bitacora` WRITE;
/*!40000 ALTER TABLE `bitacora` DISABLE KEYS */;
INSERT INTO `bitacora` VALUES (1,1,1,'14/10/2020 19:17:53','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(2,1,1,'14/10/2020 20:03:58','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(3,1,1,'14/10/2020 20:18:08','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(4,3,1,'14/10/2020 20:19:42','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(5,1,1,'14/10/2020 21:19:20','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(6,1,1,'14/10/2020 21:19:30','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(7,1,1,'14/10/2020 21:20:34','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(8,1,1,'14/10/2020 21:23:23','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(9,1,1,'14/10/2020 21:28:24','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(10,1,1,'14/10/2020 21:29:34','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(11,1,1,'14/10/2020 21:34:04','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(12,1,1,'14/10/2020 21:35:51','192.168.0.18','DESKTOP-L2EJSC3','Ingreso Exitoso'),(13,1,1,'16/10/2020 12:45:37','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(14,1,1,'16/10/2020 12:54:08','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(15,1,1,'16/10/2020 13:04:45','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(16,1,1,'16/10/2020 14:11:36','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(17,1,1,'16/10/2020 14:14:57','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(18,1,1,'16/10/2020 14:32:43','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(19,1,1,'16/10/2020 14:36:25','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(20,1,1,'16/10/2020 14:39:46','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(21,1,1,'16/10/2020 14:41:41','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(22,1,1,'16/10/2020 14:44:22','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(23,1,1,'16/10/2020 14:47:32','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(24,1,1,'16/10/2020 14:50:43','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(25,1,1,'16/10/2020 14:52:38','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(26,1,1,'16/10/2020 15:59:01','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(27,1,1,'17/10/2020 19:48:31','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(28,1,1,'17/10/2020 19:53:14','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(29,1,1,'17/10/2020 19:53:48','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(30,1,3,'17/10/2020 19:53:48','192.168.0.18','DESKTOP-L2EJSC3','Consulta Perfiles'),(31,1,3,'17/10/2020 19:53:48','192.168.0.18','DESKTOP-L2EJSC3','Consulta Aplicaciones'),(32,1,1,'17/10/2020 20:06:50','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(33,1,3,'17/10/2020 20:06:50','192.168.0.18','DESKTOP-L2EJSC3','Consulta Perfiles'),(34,1,3,'17/10/2020 20:06:50','192.168.0.18','DESKTOP-L2EJSC3','Consulta Aplicaciones'),(35,1,3,'17/10/2020 20:06:50','192.168.0.18','DESKTOP-L2EJSC3','Insercion de Aplicacion a perfil'),(36,1,3,'17/10/2020 20:06:50','192.168.0.18','DESKTOP-L2EJSC3','Consulta Perfiles'),(37,1,1,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(38,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(39,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Inserción de nuevo perfil: Gerente'),(40,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(41,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Modificacion de perfil :Gerente'),(42,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(43,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Eliminación de perfil :Gerente'),(44,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(45,1,3,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta Perfiles'),(46,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(47,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Modificacion de perfil :Gerente'),(48,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(49,1,3,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta Perfiles'),(50,1,3,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta Aplicaciones'),(51,1,3,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Insercion de Aplicacion a perfil'),(52,1,3,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta Perfiles'),(53,1,3,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Modificación de Aplicacion a perfil'),(54,1,3,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta Perfiles'),(55,1,2,'17/10/2020 20:41:04','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(56,1,1,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Logeo Exitoso'),(57,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(58,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Inserción de nuevo perfil: Prueba1'),(59,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(60,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Modificacion de perfil :Prueba1'),(61,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(62,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Eliminación de perfil :Prueba1'),(63,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(64,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil'),(65,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Modificacion de perfil :Prueba1'),(66,1,2,'17/10/2020 20:50:02','192.168.0.18','DESKTOP-L2EJSC3','Consulta perfil');
/*!40000 ALTER TABLE `bitacora` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-10-17 20:59:32
